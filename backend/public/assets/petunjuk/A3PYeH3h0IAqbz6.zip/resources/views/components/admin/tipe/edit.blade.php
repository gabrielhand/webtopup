<div class="modal fade text-left modal-borderless" id="modalEditTipe" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Tipe</h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                {{-- <form action="{{ route('tipes.update', $tipes->id) }}" method="post" id="formTipes">
                    @csrf --}}
                    <div class="form-group">
                        <input type="hidden" class="form-control" id="tipe_id" name="id">

                        <label>Nama Tipe</label>
                        <div class="input-group mt-3">
                            <input type="text" class="form-control" placeholder="eg. Game" name="name"
                                id="name_edit">
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="submit" class="btn btn-primary ms-1 btn-update" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block ">Update</span>
                </button>
            </div>
            {{-- </form> --}}
        </div>
    </div>
</div>
