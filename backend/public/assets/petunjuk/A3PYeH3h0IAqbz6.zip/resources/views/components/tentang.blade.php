@extends('layouts.master-order')

@section('content')

    <body>
        <nav class="navbar active">
            <div class="container">
                <div class="navLeft">
                    <a href="{{ route('home') }}">
                        <img src="{{ asset('assets/logo/20240123_060438.png') }}" alt="">
                    </a>
                    <div class="logoName">Tuztoz</div>
                </div>
                <div class="navRight">

                    @if (Auth::check())
                        @if (Auth::user()->role === 'Admin')
                            <a href="{{ route('dashboard') }}" class="btnYellowPrimary login">Dashboard</a>
                        @else
                            <a href="{{ route('dash') }}" class="btnYellowPrimary login">Akun</a>
                        @endif
                    @else
                        <a href="{{ url('login') }}" class="btnYellowPrimary login">Masuk</a>
                        <a href="{{ route('register') }}" class="btnYellowSecond login">Daftar</a>
                    @endif
                    <div class="containerMenu">
                        <div class="dropdown">
                            <button class="dropdownMenu shadow">
                                <i class="bi bi-grid-fill"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="{{ route('home') }}">
                                    <div class="containers">
                                        <i class="bi bi-house-door-fill"></i>
                                        <div class="name">Beranda</div>
                                    </div>
                                    <i class="bi bi-arrow-right-short"></i>
                                </a>
                                <a href="{{ url('daftar-harga') }}">
                                    <div class="containers">
                                        <i class="bi bi-tags-fill"></i>
                                        <div class="name">Daftar Harga</div>
                                    </div>
                                    <i class="bi bi-arrow-right-short"></i>
                                </a>
                                <a href="{{ route('cari') }}">
                                    <div class="containers">
                                        <i class="bi bi-receipt-cutoff"></i>
                                        <div class="name">Lacak Pesanan</div>
                                    </div>
                                    <i class="bi bi-arrow-right-short"></i>
                                </a>

                            </div>
                        </div>
                    </div>

                    <label class="theme-switch shadow">
                        <input class='toggle-checkbox' id="checkbox" type='checkbox'></input>
                        <div class="switch-icon">
                            <i class="bi bi-brightness-high yellowprim"></i>
                        </div>
                    </label>

                </div>
            </div>
        </nav>
        <div class="mobileNav">
            <a href="{{ route('home') }}" class="containers ">
                <i class="bi bi-house-door-fill"></i>
                <div class="text">Beranda</div>
            </a>

            <a href="{{ url('daftar-harga') }}" class="containers ">
                <i class="bi bi-tags-fill"></i>
                <div class="text">Daftar Harga</div>
            </a>
            <a href="{{ route('cari') }}" class="containers ">
                <i class="bi bi-receipt-cutoff"></i>
                <div class="text">Lacak Pesanan</div>
            </a>
            {{-- <a href="{{ route('login') }}" class="containers ">
                <i class="bi bi-person-fill-lock"></i>
                <div class="text">Login</div>
            </a> --}}
            @if (Auth::check())
                <a href="{{ url('account') }}" class="containers ">
                    <i class="bi bi-person-fill"></i>
                    <div class="text">Account</div>
                </a>
                @if (Auth::user()->role === 'Admin')
                    <a href="{{ url('dashboard') }}" class="containers">
                        <i class="bi bi-app-indicator"></i>
                        <div class="text">Dashboard</div>
                    </a>
                @endif
            @else
                <a href="{{ route('login') }}" class="containers ">
                    <i class="bi bi-person-fill-lock"></i>
                    <div class="text">Login</div>
                </a>
            @endif
        </div>
        <section>
            <div class="container">
                <div class="row reverse justify-content-center">
                    <div class="col-lg-8">
                        <div class="title-head mb-3">Tentang Kami</div>
                        <div class="cards shadow py-3">
                            <div class="container overflow-hidden">
                                <div class="notes">
                                    <div class="text mt-4 mb-4">
                                        <p><strong style="color: #435EBE;">{{ !$config ? '' : $config->sejarah }}</strong></p>
                                        <p>{{ !$config ? '' : $config->sejarah_1 }}</p>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong style="color: #435EBE;">Visi&nbsp;&nbsp;</strong></p>

                                                <p>{{ !$config ? '' : $config->visi }}</p>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="d-flex">
                                                    <p><strong style="color: #435EBE;">Misi</strong></p>

                                                </div>

                                                <p>{{ !$config ? '' : $config->misi }}</p>
                                            </div>

                                            <div class="col-md-7">

                                            </div>
                                        </div>
                                    

                                        {{-- <p>&nbsp;</p>

                                        <p>Terima kasih atas kepercayaan Anda pada Kiosgames.id. Kami berkomitmen untuk
                                            memberikan layanan terbaik kepada Anda.</p> --}}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- <div class="col-md-5 mt-4"> --}}
                        <div class="">

                        <div class="row">
                            <div class="col-md-5">
                                <div class="cards shadow py-3 mt-4">
                                    <div class="container overflow-hidden">
                                        <div class="notes">
                                            <div class="text mt-4 mb-4">
                                                <p><strong style="color: #435EBE;">Owner</strong></p>
                                                <img src="{{ !$config ? '' : $config->logo_ceo }}" alt="" class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="cards shadow py-3 mt-4">
                                    <div class="container overflow-hidden">
                                        <div class="notes">
                                            <div class="text mt-4 mb-4 text-center">
                                                <h5 href="{{ !$config ? '' : $config->url_ig }}"><strong style="color: #435EBE;">{{ !$config ? '' : $config->nama_ceo }}</strong></h5>
                                                <p>OWNER {{ ENV('APP_NAME') }}</p>
                                                <p class="text-center" style="margin-top: 40px">{{ !$config ? '' : $config->deskripsi_ceo }}</p>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="cards shadow py-3 mt-4">
                                    <div class="container overflow-hidden">
                                        <div class="notes">
                                            <div class="text mt-3 mb-3">
                                                <p><strong style="color: #435EBE;">Alamat</strong></p>
                                                <div class="row mt-3">
                                                    <div class="col-md-1">
                                                        <img src="/cdn/icons/alamat.svg" alt="" class="img-fluid">
                                                    </div>
                                                    <div class="col-md-11">
                                                        <p>{{ !$config ? '' : $config->nama_bagan }} <br>
                                                            {{ !$config ? '' : $config->alamat }}</p>
                                                        <p>Telephone : <a href="{{ !$config ? '' : $config->url_wa }}">{{ !$config ? '' : $config->telp }}</a></p>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                           
                        {{-- </div> --}}
                        
                        <div class="h-40"></div>
                    </div>
                </div>
            </div>
        </section>
