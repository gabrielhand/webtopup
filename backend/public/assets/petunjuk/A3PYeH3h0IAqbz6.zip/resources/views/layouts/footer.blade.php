<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <script>
                document.write(new Date().getFullYear())
            </script> &copy; {{ ENV('APP_NAME') }} by <a href=""></a>
        </div>
        <div class="float-end">
            <div class="text-md-end footer-links d-none d-sm-block">
                <a href="{{ url('/about-us') }}">About Us</a>
                <a href="https://wa.me/">Help</a>
                <a href="https://wa.me/">Contact Us</a>
            </div>
        </div>
    </div>
</footer>